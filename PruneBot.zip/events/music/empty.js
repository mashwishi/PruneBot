module.exports = async message => {
	message.channel.send(":stop_button: Channel is empty. Leaving the channel");
};

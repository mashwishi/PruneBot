module.exports = async message => {
	message.channel.send("No more song in queue");
};

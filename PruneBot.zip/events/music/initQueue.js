module.exports = async queue => {
	queue.autoplay = false;
	queue.volume = 100;
};

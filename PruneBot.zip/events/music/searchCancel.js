module.exports = async (client, message) => {
	message.channel.send(`${client.emotes.error} | Searching canceled`);
};

module.exports = function (event) {
	console.log(
		"The WebSocket has closed and will no longer attempt to reconnect"
	);
};

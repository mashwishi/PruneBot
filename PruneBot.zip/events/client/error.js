module.exports = function (event) {
	console.error(`client's WebSocket encountered a connection error: ${error}`);
};

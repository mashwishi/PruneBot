module.exports = member => {
    //const welcomeChannel = member.guild.channels.cache.find(channel => channel.name === 'welcome')
    //welcomeChannel.send (`Welcome! ${member}`)
}
